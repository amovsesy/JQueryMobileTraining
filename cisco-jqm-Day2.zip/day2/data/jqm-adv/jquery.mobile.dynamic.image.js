(function($){
     // Widget definition
     $.widget( "mobile.dynamicimage", $.mobile.widget, {
	    options: {
			margin: 0, width: 100
	    },
	    _create: function() {
			this._loadURL();
		},
		
		// Private methods
		_loadURL: function() {
        	// this.element will be our +img+ element
			
			var url; // we create the service URL
			url = "http://src.sencha.io/";
			
			var parameters = "";
			if (!isNaN(this.options.width)) {
				parameters += "x" + this.options.width;	
			}
			if ((!isNaN(this.options.margin)) && this.options.margin>0) {
				parameters += "-" + this.options.margin;	
			}
			if (parameters.length>0) {
				url += parameters + "/";	
			}
			
			// Sencha IO needs an absolute URL
			var originalUrl = $(this.element).jqmData("src");
			if (originalUrl.length>1) {
				var newUrl = "";
				if ($.mobile.path.isAbsoluteUrl(originalUrl)) {
					// The image URL is already absolute
					newUrl = originalUrl;
				} else {
					// The image URL is relative, we create an absolute one
					var baseUrl = $.mobile.path.parseUrl(location.href);
					var baseUrlWithoutScript = baseUrl.protocol + "//" + baseUrl.host + baseUrl.directory;
					newUrl = $.mobile.path.makeUrlAbsolute(originalUrl, baseUrlWithoutScript);	
				}
				
				url += newUrl;
				
				$(this.element).attr("src", url);	
			}
		},
				
		// Public methods
	    enable: function() { 
	        // Enable the widget
			$(this.element).attr('disabled', '');
	    },
	    disable: function() { 
	        // Disable the widget
			$(this.element).removeAttr('disabled');			
	    },
	    refresh: function() { 
	        // Refresh the widget
			this._loadURL();
	    }
    });
    // End of widget definition
    
    // Auto-initialization code
    $(document).bind("pagecreate", function(event) {
        // We find data-role's and apply our widget constructor
        $(event.target).find("img:jqmData(role='dynamic-image')").dynamicimage();
    
    });
    
}(jQuery));
