<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>jQM Conference</title>
<meta name="viewport" content="width=device-width,user-scalable=no">
<link rel="stylesheet" href="jquery.mobile-1.0.css" />
<script src="jquery.js"></script>
<script src="script.js"></script>
<script src="jquery.mobile-1.0.js"></script>
</head>

<body>

<div data-role="dialog">

  <div data-role="header">
    <h1>Feedback</h1>
  </div>
  
  <div data-role="content">
     
     <?php 
	 // Validation and processing here 
	 
	 ?>
     Thanks for your feedback.
     
     <a data-role="button" data-inverse="true" href="index.html">Close</a>
     
  </div>
  
</div>
</body>
</html>
