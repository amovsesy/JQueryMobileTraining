HI! WELCOME TO MARAKANA TRAINING FOR HEWLETT-PACKARD DELIVERED BY MAX FIRTMAN (@firt)

Open index.html on Safari, Firefox or Chrome (only under HTTP server) and have fun!

This material is only for authorized attendees to the training.