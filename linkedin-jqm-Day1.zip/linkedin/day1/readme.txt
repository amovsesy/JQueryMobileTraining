HI! WELCOME TO MARAKANA TRAINING DELIVERED BY MAX FIRTMAN (@firt)

Open index.html on Safari, Firefox or Chrome (only under HTTP server) and have fun!

